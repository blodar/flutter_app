import 'package:daftar_alhisabat/models/models.dart';
import 'package:daftar_alhisabat/utils/format.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('parseAmount', () {
    test('يقبل الأرقام الإنجليزية والعربية', () {
      expect(parseAmount('1500'), 1500);
      expect(parseAmount('١٥٠٠'), 1500);
      expect(parseAmount('12.5'), 12.5);
      expect(parseAmount('١٢٫٥'), 12.5);
      expect(parseAmount('1,500'), 1500);
    });

    test('يرفض القيم غير الصالحة', () {
      expect(parseAmount(''), isNull);
      expect(parseAmount('abc'), isNull);
      expect(parseAmount('0'), isNull);
      expect(parseAmount('-5'), isNull);
    });
  });

  test('إشارة العملية', () {
    const a = Entry(
        personId: 1, amount: 100, currency: 'ريال', kind: kReceivable, date: 0);
    const b = Entry(
        personId: 1, amount: 40, currency: 'ريال', kind: kPayable, date: 0);
    expect(a.signed + b.signed, 60);
  });

  test('تنسيق المبلغ', () {
    expect(fmtAmount(12500.5), '12,500.5');
    expect(fmtAmount(3), '3');
  });
}
