import 'package:flutter/material.dart';

import '../utils/format.dart';

Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  String action = 'تأكيد',
  bool danger = false,
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          style: danger
              ? FilledButton.styleFrom(
                  backgroundColor: Theme.of(ctx).colorScheme.error,
                  foregroundColor: Theme.of(ctx).colorScheme.onError,
                )
              : null,
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(action),
        ),
      ],
    ),
  );
  return result ?? false;
}

void showSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

/// سطر رصيد واحد: "1,500 ريال  لي عنده"
Widget balanceLine(BuildContext context, String currency, double value,
    {double size = 14}) {
  final positive = value > 0;
  final color = positive ? receivableColor(context) : payableColor(context);
  return Text.rich(
    TextSpan(children: [
      TextSpan(
        text: '${fmtAmount(value.abs())} $currency',
        style:
            TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: size),
      ),
      TextSpan(
        text: positive ? '  لي عنده' : '  له عندي',
        style: TextStyle(color: color, fontSize: size - 3),
      ),
    ]),
  );
}
