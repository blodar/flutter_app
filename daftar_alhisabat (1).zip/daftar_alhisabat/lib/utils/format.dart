import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

final NumberFormat _numFmt = NumberFormat('#,##0.##', 'en');

/// تنسيق المبلغ بأرقام إنجليزية وفواصل آلاف: 12,500.5
String fmtAmount(double v) => _numFmt.format(v);

String fmtDate(int ms) => fmtDateTime(DateTime.fromMillisecondsSinceEpoch(ms));

String fmtDateTime(DateTime d) => DateFormat('yyyy/MM/dd', 'en').format(d);

/// يحوّل الأرقام العربية والفارسية إلى إنجليزية ويتجاهل فواصل الآلاف
String normalizeDigits(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  final b = StringBuffer();
  for (final rune in s.runes) {
    final ch = String.fromCharCode(rune);
    final i = ar.indexOf(ch);
    final j = fa.indexOf(ch);
    if (i >= 0) {
      b.write(i);
    } else if (j >= 0) {
      b.write(j);
    } else if (ch == '٫') {
      b.write('.');
    } else if (ch == '٬' || ch == '،' || ch == ',' || ch == ' ') {
      // فواصل الآلاف: تُتجاهل
    } else {
      b.write(ch);
    }
  }
  return b.toString();
}

/// يرجع null إذا كان المبلغ غير صالح أو أقل من أو يساوي صفر
double? parseAmount(String s) {
  final t = normalizeDigits(s).trim();
  if (t.isEmpty) return null;
  final v = double.tryParse(t);
  if (v == null || v.isNaN || v.isInfinite || v <= 0) return null;
  return v;
}

String initialOf(String name) {
  final t = name.trim();
  if (t.isEmpty) return '؟';
  return String.fromCharCode(t.runes.first);
}

Color receivableColor(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark
        ? const Color(0xFF5FD3A0)
        : const Color(0xFF14804F);

Color payableColor(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark
        ? const Color(0xFFFF8A80)
        : const Color(0xFFC62828);
