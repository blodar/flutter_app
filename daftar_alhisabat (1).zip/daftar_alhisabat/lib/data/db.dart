import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/models.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _db;

  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final path = p.join(await getDatabasesPath(), 'ledger.db');
    return openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE persons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL DEFAULT '',
            created_at INTEGER NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            person_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            currency TEXT NOT NULL,
            kind INTEGER NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            date INTEGER NOT NULL,
            due INTEGER,
            FOREIGN KEY (person_id) REFERENCES persons (id) ON DELETE CASCADE
          )
        ''');
        await db.execute(
            'CREATE INDEX idx_entries_person ON entries (person_id)');
        await db.execute('''
          CREATE TABLE settings (
            k TEXT PRIMARY KEY,
            v TEXT NOT NULL
          )
        ''');
      },
    );
  }

  // ---------- الأشخاص ----------
  Future<List<Person>> loadPersons() async {
    final db = await database;
    final rows = await db.query('persons', orderBy: 'id ASC');
    return rows.map(Person.fromMap).toList();
  }

  Future<int> insertPerson(Person person) async {
    final db = await database;
    return db.insert('persons', person.toMap());
  }

  Future<void> updatePerson(int id, String name, String phone) async {
    final db = await database;
    await db.update('persons', {'name': name, 'phone': phone},
        where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deletePerson(int id) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('entries', where: 'person_id = ?', whereArgs: [id]);
      await txn.delete('persons', where: 'id = ?', whereArgs: [id]);
    });
  }

  // ---------- العمليات ----------
  Future<List<Entry>> loadEntries() async {
    final db = await database;
    final rows = await db.query('entries', orderBy: 'date DESC, id DESC');
    return rows.map(Entry.fromMap).toList();
  }

  Future<int> insertEntry(Entry e) async {
    final db = await database;
    return db.insert('entries', e.toMap());
  }

  Future<void> updateEntry(Entry e) async {
    final db = await database;
    await db.update('entries', e.toMap(), where: 'id = ?', whereArgs: [e.id]);
  }

  Future<void> deleteEntry(int id) async {
    final db = await database;
    await db.delete('entries', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- الإعدادات ----------
  Future<String?> getSetting(String key) async {
    final db = await database;
    final rows =
        await db.query('settings', where: 'k = ?', whereArgs: [key], limit: 1);
    if (rows.isEmpty) return null;
    return rows.first['v'] as String?;
  }

  Future<void> setSetting(String key, String value) async {
    final db = await database;
    await db.insert('settings', {'k': key, 'v': value},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ---------- الاستيراد ----------
  Future<void> replaceAll(List<Person> persons, List<Entry> entries) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('entries');
      await txn.delete('persons');
      for (final person in persons) {
        await txn.insert('persons', person.toMap());
      }
      for (final e in entries) {
        await txn.insert('entries', e.toMap());
      }
    });
  }
}
