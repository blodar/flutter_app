/// نوع العملية: لي عنده (يدين لي) = 1 ، له عندي (أدين له) = -1
const int kReceivable = 1;
const int kPayable = -1;

/// ملاحظة العملية التلقائية عند تسديد حساب
const String kSettleNote = 'تسديد';

const List<String> kDefaultCurrencies = ['ريال', 'دولار', 'درهم', 'دينار'];

class Person {
  final int? id;
  final String name;
  final String phone;
  final int createdAt;

  const Person({
    this.id,
    required this.name,
    this.phone = '',
    required this.createdAt,
  });

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'phone': phone,
        'created_at': createdAt,
      };

  factory Person.fromMap(Map<String, Object?> m) => Person(
        id: (m['id'] as num?)?.toInt(),
        name: m['name'] as String,
        phone: (m['phone'] as String?) ?? '',
        createdAt: (m['created_at'] as num).toInt(),
      );
}

class Entry {
  final int? id;
  final int personId;
  final double amount;
  final String currency;
  final int kind; // kReceivable أو kPayable
  final String note;
  final int date; // millisecondsSinceEpoch
  final int? due; // تاريخ الاستحقاق (اختياري)

  const Entry({
    this.id,
    required this.personId,
    required this.amount,
    required this.currency,
    required this.kind,
    this.note = '',
    required this.date,
    this.due,
  });

  double get signed => kind * amount;

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'person_id': personId,
        'amount': amount,
        'currency': currency,
        'kind': kind,
        'note': note,
        'date': date,
        'due': due,
      };

  factory Entry.fromMap(Map<String, Object?> m) => Entry(
        id: (m['id'] as num?)?.toInt(),
        personId: (m['person_id'] as num).toInt(),
        amount: (m['amount'] as num).toDouble(),
        currency: m['currency'] as String,
        kind: (m['kind'] as num).toInt(),
        note: (m['note'] as String?) ?? '',
        date: (m['date'] as num).toInt(),
        due: (m['due'] as num?)?.toInt(),
      );
}

class CurrencyTotals {
  double receivable = 0;
  double payable = 0;
  double get net => receivable - payable;
}

class MonthStat {
  final DateTime month;
  final double lent;
  final double borrowed;
  const MonthStat(this.month, this.lent, this.borrowed);
}
