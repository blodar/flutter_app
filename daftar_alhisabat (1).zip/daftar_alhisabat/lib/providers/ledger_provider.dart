import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../data/db.dart';
import '../models/models.dart';
import '../utils/format.dart';

class LedgerProvider extends ChangeNotifier {
  final AppDatabase _db = AppDatabase.instance;

  List<Person> _persons = [];
  List<Entry> _entries = [];
  final Map<int, Map<String, double>> _balances = {};
  final Map<int, int> _lastActivity = {};

  List<String> _currencies = [...kDefaultCurrencies];
  String _defaultCurrency = kDefaultCurrencies.first;
  ThemeMode _themeMode = ThemeMode.system;

  List<Person> get persons => _persons;
  List<Entry> get entries => _entries;
  List<String> get currencies => _currencies;
  String get defaultCurrency => _defaultCurrency;
  ThemeMode get themeMode => _themeMode;

  // ------------------------------------------------------------------
  // التهيئة
  // ------------------------------------------------------------------
  Future<void> init() async {
    await _loadSettings();
    await _reload();
  }

  Future<void> _loadSettings() async {
    final cur = await _db.getSetting('currencies');
    if (cur != null) {
      try {
        final list = (jsonDecode(cur) as List)
            .map((e) => e.toString().trim())
            .where((e) => e.isNotEmpty)
            .toList();
        if (list.isNotEmpty) _currencies = list;
      } catch (_) {}
    }
    final def = await _db.getSetting('default_currency');
    _defaultCurrency =
        (def != null && _currencies.contains(def)) ? def : _currencies.first;
    final theme = await _db.getSetting('theme');
    _themeMode = switch (theme) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
  }

  Future<void> _reload() async {
    _persons = await _db.loadPersons();
    _entries = await _db.loadEntries();
    _recompute();
    notifyListeners();
  }

  void _recompute() {
    _balances.clear();
    _lastActivity.clear();
    for (final e in _entries) {
      final m = _balances.putIfAbsent(e.personId, () => <String, double>{});
      m[e.currency] = (m[e.currency] ?? 0) + e.signed;
      final last = _lastActivity[e.personId] ?? 0;
      if (e.date > last) _lastActivity[e.personId] = e.date;
    }
    for (final m in _balances.values) {
      m.removeWhere((_, v) => v.abs() < 0.005);
    }
  }

  // ------------------------------------------------------------------
  // الاستعلامات
  // ------------------------------------------------------------------
  Person? personById(int id) {
    for (final p in _persons) {
      if (p.id == id) return p;
    }
    return null;
  }

  int? lastActivityOf(int personId) => _lastActivity[personId];

  int _currencyRank(String c) {
    final i = _currencies.indexOf(c);
    return i < 0 ? 1000 : i;
  }

  /// أرصدة الشخص مرتبة حسب ترتيب العملات في الإعدادات
  List<MapEntry<String, double>> balanceList(int personId) {
    final m = _balances[personId];
    if (m == null) return const [];
    final list = m.entries.toList()
      ..sort((a, b) => _currencyRank(a.key).compareTo(_currencyRank(b.key)));
    return list;
  }

  /// مجموع القيم المطلقة لأرصدة الشخص (للترتيب)
  double absBalanceOf(int personId) {
    final m = _balances[personId];
    if (m == null) return 0;
    return m.values.fold<double>(0, (s, v) => s + v.abs());
  }

  List<Entry> entriesOf(int personId) {
    final list = _entries.where((e) => e.personId == personId).toList();
    list.sort((a, b) {
      final c = b.date.compareTo(a.date);
      return c != 0 ? c : (b.id ?? 0).compareTo(a.id ?? 0);
    });
    return list;
  }

  /// إجمالي ما لي وما علي لكل عملة (على أساس صافي كل شخص)
  Map<String, CurrencyTotals> totals() {
    final result = <String, CurrencyTotals>{};
    for (final m in _balances.values) {
      m.forEach((cur, v) {
        final t = result.putIfAbsent(cur, () => CurrencyTotals());
        if (v > 0) {
          t.receivable += v;
        } else {
          t.payable += -v;
        }
      });
    }
    final keys = result.keys.toList()
      ..sort((a, b) => _currencyRank(a).compareTo(_currencyRank(b)));
    return {for (final k in keys) k: result[k]!};
  }

  /// العملات المستخدمة فعلاً في العمليات
  List<String> get usedCurrencies {
    final set = _entries.map((e) => e.currency).toSet().toList();
    set.sort((a, b) => _currencyRank(a).compareTo(_currencyRank(b)));
    return set;
  }

  bool currencyInUse(String c) => _entries.any((e) => e.currency == c);

  /// أكبر الأرصدة لعملة معينة: positive=true لمن عليهم لي، false لمن لهم عندي
  List<MapEntry<Person, double>> topBalances(String currency,
      {required bool positive, int limit = 5}) {
    final list = <MapEntry<Person, double>>[];
    for (final p in _persons) {
      final v = _balances[p.id]?[currency] ?? 0;
      if (positive && v > 0) list.add(MapEntry(p, v));
      if (!positive && v < 0) list.add(MapEntry(p, -v));
    }
    list.sort((a, b) => b.value.compareTo(a.value));
    return list.take(limit).toList();
  }

  List<MonthStat> monthlyStats(String currency, {int months = 6}) {
    final now = DateTime.now();
    final result = <MonthStat>[];
    for (int i = months - 1; i >= 0; i--) {
      final start = DateTime(now.year, now.month - i, 1);
      final end = DateTime(now.year, now.month - i + 1, 1);
      double lent = 0;
      double borrowed = 0;
      for (final e in _entries) {
        if (e.currency != currency || e.note == kSettleNote) continue;
        final d = DateTime.fromMillisecondsSinceEpoch(e.date);
        if (d.isBefore(start) || !d.isBefore(end)) continue;
        if (e.kind == kReceivable) {
          lent += e.amount;
        } else {
          borrowed += e.amount;
        }
      }
      result.add(MonthStat(start, lent, borrowed));
    }
    return result;
  }

  /// هل العملية متأخرة؟ (تجاوزت الاستحقاق وما زال الرصيد قائماً بنفس الاتجاه)
  bool isOverdue(Entry e) {
    if (e.due == null) return false;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    if (e.due! >= today) return false;
    final bal = _balances[e.personId]?[e.currency] ?? 0;
    return bal != 0 && (bal > 0) == (e.kind > 0);
  }

  int get overdueCount => _entries.where(isOverdue).length;

  // ------------------------------------------------------------------
  // التعديلات
  // ------------------------------------------------------------------
  Future<int> personIdForName(String name) async {
    final n = name.trim();
    for (final p in _persons) {
      if (p.name.trim().toLowerCase() == n.toLowerCase()) return p.id!;
    }
    return _db.insertPerson(
      Person(name: n, createdAt: DateTime.now().millisecondsSinceEpoch),
    );
  }

  Future<void> updatePerson(int id, String name, String phone) async {
    await _db.updatePerson(id, name, phone);
    await _reload();
  }

  Future<void> deletePerson(int id) async {
    await _db.deletePerson(id);
    await _reload();
  }

  Future<void> addEntry(Entry e) async {
    await _db.insertEntry(e);
    await _reload();
  }

  Future<void> updateEntry(Entry e) async {
    await _db.updateEntry(e);
    await _reload();
  }

  Future<void> deleteEntry(int id) async {
    await _db.deleteEntry(id);
    await _reload();
  }

  /// تسديد الرصيد القائم بعملية معاكسة
  Future<void> settle(int personId, String currency) async {
    final bal = _balances[personId]?[currency] ?? 0;
    if (bal.abs() < 0.005) return;
    final now = DateTime.now();
    await addEntry(Entry(
      personId: personId,
      amount: bal.abs(),
      currency: currency,
      kind: bal > 0 ? kPayable : kReceivable,
      note: kSettleNote,
      date: DateTime(now.year, now.month, now.day).millisecondsSinceEpoch,
    ));
  }

  // ------------------------------------------------------------------
  // الإعدادات
  // ------------------------------------------------------------------
  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    await _db.setSetting('theme', switch (mode) {
      ThemeMode.light => 'light',
      ThemeMode.dark => 'dark',
      ThemeMode.system => 'system',
    });
    notifyListeners();
  }

  Future<void> _saveCurrencies() async {
    await _db.setSetting('currencies', jsonEncode(_currencies));
    await _db.setSetting('default_currency', _defaultCurrency);
    notifyListeners();
  }

  /// يرجع false إذا كانت العملة موجودة مسبقاً أو فارغة
  Future<bool> addCurrency(String name) async {
    final n = name.trim();
    if (n.isEmpty || _currencies.contains(n)) return false;
    _currencies = [..._currencies, n];
    await _saveCurrencies();
    return true;
  }

  /// يرجع false إذا كانت مستخدمة أو هي العملة الوحيدة
  Future<bool> removeCurrency(String name) async {
    if (_currencies.length <= 1 || currencyInUse(name)) return false;
    _currencies = _currencies.where((c) => c != name).toList();
    if (_defaultCurrency == name) _defaultCurrency = _currencies.first;
    await _saveCurrencies();
    return true;
  }

  Future<void> setDefaultCurrency(String name) async {
    if (!_currencies.contains(name)) return;
    _defaultCurrency = name;
    await _saveCurrencies();
  }

  // ------------------------------------------------------------------
  // كشف الحساب والنسخ الاحتياطي
  // ------------------------------------------------------------------
  String statementFor(Person p) {
    final b = StringBuffer();
    b.writeln('كشف حساب: ${p.name}');
    b.writeln('بتاريخ: ${fmtDateTime(DateTime.now())}');
    b.writeln('────────────');
    final bal = balanceList(p.id!);
    if (bal.isEmpty) {
      b.writeln('الرصيد: مسدّد بالكامل');
    } else {
      b.writeln('الرصيد الحالي:');
      for (final e in bal) {
        final label = e.value > 0 ? 'عليك' : 'لك';
        b.writeln('• $label ${fmtAmount(e.value.abs())} ${e.key}');
      }
    }
    final list = entriesOf(p.id!);
    if (list.isNotEmpty) {
      b.writeln('────────────');
      b.writeln('العمليات:');
      for (final e in list) {
        final label = e.kind == kReceivable ? 'عليك' : 'لك';
        final note = e.note.isEmpty ? '' : ' — ${e.note}';
        b.writeln(
            '${fmtDate(e.date)}  $label ${fmtAmount(e.amount)} ${e.currency}$note');
      }
    }
    b.writeln('────────────');
    b.write('دفتر الحسابات');
    return b.toString();
  }

  String exportJson() {
    final data = {
      'app': 'daftar_alhisabat',
      'version': 1,
      'exported_at': DateTime.now().toIso8601String(),
      'persons': _persons.map((p) => p.toMap()).toList(),
      'entries': _entries.map((e) => e.toMap()).toList(),
      'settings': {
        'currencies': _currencies,
        'default_currency': _defaultCurrency,
      },
    };
    return const JsonEncoder.withIndent('  ').convert(data);
  }

  /// يستبدل كل البيانات الحالية بمحتوى النسخة الاحتياطية
  Future<void> importJson(String text) async {
    final data = jsonDecode(text);
    if (data is! Map || data['app'] != 'daftar_alhisabat') {
      throw const FormatException('الملف ليس نسخة احتياطية من دفتر الحسابات');
    }
    final personsRaw = data['persons'];
    final entriesRaw = data['entries'];
    if (personsRaw is! List || entriesRaw is! List) {
      throw const FormatException('بنية الملف غير صحيحة');
    }
    final persons = personsRaw
        .map((e) => Person.fromMap(Map<String, Object?>.from(e as Map)))
        .toList();
    if (persons.any((p) => p.id == null)) {
      throw const FormatException('بنية الملف غير صحيحة');
    }
    final ids = persons.map((p) => p.id).toSet();
    final entries = entriesRaw
        .map((e) => Entry.fromMap(Map<String, Object?>.from(e as Map)))
        .where((e) => ids.contains(e.personId))
        .toList();

    await _db.replaceAll(persons, entries);

    final settings = data['settings'];
    if (settings is Map) {
      final cur = settings['currencies'];
      if (cur is List) {
        final list = cur
            .map((e) => e.toString().trim())
            .where((e) => e.isNotEmpty)
            .toList();
        if (list.isNotEmpty) _currencies = list;
      }
      final def = settings['default_currency'];
      _defaultCurrency =
          (def is String && _currencies.contains(def)) ? def : _currencies.first;
    }
    // تأكد أن كل عملة مستخدمة موجودة في القائمة
    for (final c in entries.map((e) => e.currency).toSet()) {
      if (!_currencies.contains(c)) _currencies = [..._currencies, c];
    }
    await _db.setSetting('currencies', jsonEncode(_currencies));
    await _db.setSetting('default_currency', _defaultCurrency);
    await _reload();
  }

  /// أقصى قيمة بين عدة أرقام (يُستخدم في الرسوم البيانية)
  static double maxOf(Iterable<double> values) =>
      values.fold<double>(0, (m, v) => math.max(m, v));
}
