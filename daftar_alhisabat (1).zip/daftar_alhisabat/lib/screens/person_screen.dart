import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../models/models.dart';
import '../providers/ledger_provider.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'entry_sheet.dart';

class PersonScreen extends StatelessWidget {
  final int personId;
  const PersonScreen({super.key, required this.personId});

  @override
  Widget build(BuildContext context) {
    final ledger = context.watch<LedgerProvider>();
    final person = ledger.personById(personId);
    if (person == null) {
      return const Scaffold(body: SizedBox.shrink());
    }
    final balances = ledger.balanceList(personId);
    final entries = ledger.entriesOf(personId);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(person.name),
        actions: [
          IconButton(
            tooltip: 'مشاركة كشف الحساب',
            icon: const Icon(Icons.share_outlined),
            onPressed: () => Share.share(
              ledger.statementFor(person),
              subject: 'كشف حساب ${person.name}',
            ),
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'edit') _editPerson(context, person);
              if (v == 'delete') _deletePerson(context, person);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: Text('تعديل بيانات الحساب')),
              PopupMenuItem(value: 'delete', child: Text('حذف الحساب')),
            ],
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          Card(
            margin: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (person.phone.isNotEmpty) ...[
                    Row(
                      children: [
                        const Icon(Icons.phone_outlined, size: 18),
                        const SizedBox(width: 6),
                        Text(person.phone),
                      ],
                    ),
                    const SizedBox(height: 10),
                  ],
                  Text('الرصيد الحالي', style: theme.textTheme.titleMedium),
                  const SizedBox(height: 8),
                  if (balances.isEmpty)
                    const Text('الحساب مسدّد بالكامل')
                  else
                    for (final b in balances)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Row(
                          children: [
                            Expanded(
                                child:
                                    balanceLine(context, b.key, b.value, size: 18)),
                            TextButton(
                              onPressed: () => _settle(context, person, b),
                              child: const Text('تسديد'),
                            ),
                          ],
                        ),
                      ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.tonalIcon(
                          onPressed: () => showEntrySheet(context,
                              person: person, initialKind: kReceivable),
                          icon: const Icon(Icons.south_west),
                          label: const Text('لي عنده'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: FilledButton.tonalIcon(
                          onPressed: () => showEntrySheet(context,
                              person: person, initialKind: kPayable),
                          icon: const Icon(Icons.north_east),
                          label: const Text('له عندي'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
            child: Text('العمليات (${entries.length})',
                style: theme.textTheme.titleMedium),
          ),
          if (entries.isEmpty)
            const Padding(
              padding: EdgeInsets.all(32),
              child: Center(child: Text('لا توجد عمليات بعد')),
            ),
          for (final e in entries) _EntryTile(entry: e, ledger: ledger),
        ],
      ),
    );
  }

  Future<void> _settle(
      BuildContext context, Person person, MapEntry<String, double> b) async {
    final owedToMe = b.value > 0;
    final ok = await confirmDialog(
      context,
      title: 'تسديد الحساب',
      message: owedToMe
          ? 'سيتم تسجيل أن ${person.name} سدّد ${fmtAmount(b.value.abs())} ${b.key}.'
          : 'سيتم تسجيل أنك سدّدت ${fmtAmount(b.value.abs())} ${b.key} لـ ${person.name}.',
      action: 'تأكيد التسديد',
    );
    if (!ok || !context.mounted) return;
    await context.read<LedgerProvider>().settle(person.id!, b.key);
  }

  Future<void> _editPerson(BuildContext context, Person p) async {
    final name = TextEditingController(text: p.name);
    final phone = TextEditingController(text: p.phone);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعديل الحساب'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: name,
              decoration: const InputDecoration(labelText: 'الاسم'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: phone,
              keyboardType: TextInputType.phone,
              decoration:
                  const InputDecoration(labelText: 'رقم الهاتف (اختياري)'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true || name.text.trim().isEmpty || !context.mounted) return;
    await context
        .read<LedgerProvider>()
        .updatePerson(p.id!, name.text.trim(), phone.text.trim());
  }

  Future<void> _deletePerson(BuildContext context, Person p) async {
    final ok = await confirmDialog(
      context,
      title: 'حذف الحساب',
      message: 'سيتم حذف ${p.name} وجميع عملياته نهائياً. لا يمكن التراجع.',
      action: 'حذف',
      danger: true,
    );
    if (!ok || !context.mounted) return;
    final navigator = Navigator.of(context);
    final ledger = context.read<LedgerProvider>();
    navigator.pop();
    await ledger.deletePerson(p.id!);
  }
}

class _EntryTile extends StatelessWidget {
  final Entry entry;
  final LedgerProvider ledger;
  const _EntryTile({required this.entry, required this.ledger});

  @override
  Widget build(BuildContext context) {
    final receivable = entry.kind == kReceivable;
    final color = receivable ? receivableColor(context) : payableColor(context);
    final overdue = ledger.isOverdue(entry);
    final theme = Theme.of(context);

    final lines = <String>[
      fmtDate(entry.date),
      if (entry.note.isNotEmpty) entry.note,
    ];

    return ListTile(
      leading: CircleAvatar(
        backgroundColor: color.withAlpha(36),
        foregroundColor: color,
        child: Icon(receivable ? Icons.south_west : Icons.north_east),
      ),
      title: Text.rich(TextSpan(children: [
        TextSpan(
          text: '${fmtAmount(entry.amount)} ${entry.currency}',
          style: TextStyle(color: color, fontWeight: FontWeight.bold),
        ),
        TextSpan(
          text: receivable ? '  لي عنده' : '  له عندي',
          style: theme.textTheme.bodySmall,
        ),
      ])),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(lines.join(' • ')),
          if (entry.due != null)
            Text(
              overdue
                  ? 'متأخر — الاستحقاق ${fmtDate(entry.due!)}'
                  : 'الاستحقاق ${fmtDate(entry.due!)}',
              style: TextStyle(
                color: overdue
                    ? theme.colorScheme.error
                    : theme.colorScheme.outline,
                fontSize: 12,
              ),
            ),
        ],
      ),
      trailing: PopupMenuButton<String>(
        onSelected: (v) async {
          if (v == 'edit') {
            await showEntrySheet(context, entry: entry);
          } else if (v == 'delete') {
            final ok = await confirmDialog(
              context,
              title: 'حذف العملية',
              message:
                  'هل تريد حذف عملية ${fmtAmount(entry.amount)} ${entry.currency}؟',
              action: 'حذف',
              danger: true,
            );
            if (ok && context.mounted) {
              await context.read<LedgerProvider>().deleteEntry(entry.id!);
            }
          }
        },
        itemBuilder: (_) => const [
          PopupMenuItem(value: 'edit', child: Text('تعديل')),
          PopupMenuItem(value: 'delete', child: Text('حذف')),
        ],
      ),
    );
  }
}
