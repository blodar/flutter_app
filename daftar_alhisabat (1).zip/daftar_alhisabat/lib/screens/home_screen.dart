import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/ledger_provider.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import 'entry_sheet.dart';
import 'person_screen.dart';
import 'reports_screen.dart';
import 'settings_screen.dart';

enum SortMode { recent, name, balance }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _search = TextEditingController();
  String _query = '';
  SortMode _sort = SortMode.recent;

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<Person> _visible(LedgerProvider ledger) {
    final q = normalizeDigits(_query).trim().toLowerCase();
    final list = ledger.persons.where((p) {
      if (q.isEmpty) return true;
      return p.name.toLowerCase().contains(q) ||
          normalizeDigits(p.phone).contains(q);
    }).toList();

    switch (_sort) {
      case SortMode.recent:
        list.sort((a, b) {
          final la = ledger.lastActivityOf(a.id!) ?? a.createdAt;
          final lb = ledger.lastActivityOf(b.id!) ?? b.createdAt;
          return lb.compareTo(la);
        });
      case SortMode.name:
        list.sort((a, b) => a.name.compareTo(b.name));
      case SortMode.balance:
        list.sort((a, b) =>
            ledger.absBalanceOf(b.id!).compareTo(ledger.absBalanceOf(a.id!)));
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final ledger = context.watch<LedgerProvider>();
    final list = _visible(ledger);

    return Scaffold(
      appBar: AppBar(
        title: const Text('دفتر الحسابات'),
        actions: [
          IconButton(
            tooltip: 'التقارير',
            icon: const Icon(Icons.insights_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const ReportsScreen()),
            ),
          ),
          IconButton(
            tooltip: 'الإعدادات',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showEntrySheet(context),
        icon: const Icon(Icons.add),
        label: const Text('عملية جديدة'),
      ),
      body: ledger.persons.isEmpty
          ? _EmptyState(onAdd: () => showEntrySheet(context))
          : CustomScrollView(
              slivers: [
                SliverToBoxAdapter(child: _SummaryCard(ledger: ledger)),
                SliverToBoxAdapter(child: _buildSearchRow()),
                if (list.isEmpty)
                  const SliverToBoxAdapter(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Center(child: Text('لا توجد نتائج مطابقة')),
                    ),
                  ),
                SliverList.builder(
                  itemCount: list.length,
                  itemBuilder: (context, i) =>
                      _PersonTile(person: list[i], ledger: ledger),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 96)),
              ],
            ),
    );
  }

  Widget _buildSearchRow() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _search,
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: 'بحث بالاسم أو رقم الهاتف',
                prefixIcon: const Icon(Icons.search),
                isDense: true,
                suffixIcon: _query.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _search.clear();
                          setState(() => _query = '');
                        },
                      ),
              ),
            ),
          ),
          PopupMenuButton<SortMode>(
            tooltip: 'ترتيب',
            icon: const Icon(Icons.sort),
            initialValue: _sort,
            onSelected: (m) => setState(() => _sort = m),
            itemBuilder: (_) => const [
              PopupMenuItem(value: SortMode.recent, child: Text('الأحدث نشاطاً')),
              PopupMenuItem(value: SortMode.name, child: Text('حسب الاسم')),
              PopupMenuItem(
                  value: SortMode.balance, child: Text('الأكبر رصيداً')),
            ],
          ),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final LedgerProvider ledger;
  const _SummaryCard({required this.ledger});

  @override
  Widget build(BuildContext context) {
    final totals = ledger.totals();
    final overdue = ledger.overdueCount;
    final theme = Theme.of(context);
    final green = receivableColor(context);
    final red = payableColor(context);

    return Card(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('ملخص الحسابات', style: theme.textTheme.titleMedium),
            const SizedBox(height: 12),
            if (totals.isEmpty)
              const Text('كل الحسابات مسدّدة حالياً')
            else
              for (final entry in totals.entries)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 56,
                        child: Text(entry.key,
                            style: theme.textTheme.labelLarge),
                      ),
                      Expanded(
                        child: _stat(context, 'لي', entry.value.receivable, green),
                      ),
                      Expanded(
                        child: _stat(context, 'علي', entry.value.payable, red),
                      ),
                    ],
                  ),
                ),
            if (overdue > 0) ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  Icon(Icons.warning_amber_rounded,
                      size: 18, color: theme.colorScheme.error),
                  const SizedBox(width: 6),
                  Text(
                    'لديك $overdue ${overdue == 1 ? 'عملية متأخرة' : 'عمليات متأخرة'} عن موعد الاستحقاق',
                    style: TextStyle(color: theme.colorScheme.error),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _stat(BuildContext context, String label, double value, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: Theme.of(context).textTheme.bodySmall),
        Text(
          fmtAmount(value),
          style: TextStyle(
              color: color, fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ],
    );
  }
}

class _PersonTile extends StatelessWidget {
  final Person person;
  final LedgerProvider ledger;
  const _PersonTile({required this.person, required this.ledger});

  @override
  Widget build(BuildContext context) {
    final balances = ledger.balanceList(person.id!);
    final last = ledger.lastActivityOf(person.id!);

    return ListTile(
      leading: CircleAvatar(child: Text(initialOf(person.name))),
      title: Text(person.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(
        last == null ? 'بدون عمليات' : 'آخر عملية: ${fmtDate(last)}',
      ),
      trailing: balances.isEmpty
          ? Text('مسدّد',
              style: TextStyle(color: Theme.of(context).colorScheme.outline))
          : Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final b in balances.take(3))
                  balanceLine(context, b.key, b.value),
              ],
            ),
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute<void>(
          builder: (_) => PersonScreen(personId: person.id!),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final VoidCallback onAdd;
  const _EmptyState({required this.onAdd});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.menu_book_outlined,
                size: 72, color: theme.colorScheme.primary),
            const SizedBox(height: 16),
            Text('دفترك فارغ', style: theme.textTheme.titleLarge),
            const SizedBox(height: 8),
            const Text(
              'سجّل أول عملية لتبدأ بتتبع ما لك وما عليك',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: onAdd,
              icon: const Icon(Icons.add),
              label: const Text('إضافة عملية'),
            ),
          ],
        ),
      ),
    );
  }
}
