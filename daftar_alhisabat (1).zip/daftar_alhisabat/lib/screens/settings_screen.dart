import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../providers/ledger_provider.dart';
import '../widgets/common.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ledger = context.watch<LedgerProvider>();
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: [
          _section(context, 'المظهر'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SegmentedButton<ThemeMode>(
              segments: const [
                ButtonSegment(
                    value: ThemeMode.system,
                    label: Text('تلقائي'),
                    icon: Icon(Icons.brightness_auto)),
                ButtonSegment(
                    value: ThemeMode.light,
                    label: Text('فاتح'),
                    icon: Icon(Icons.light_mode_outlined)),
                ButtonSegment(
                    value: ThemeMode.dark,
                    label: Text('داكن'),
                    icon: Icon(Icons.dark_mode_outlined)),
              ],
              selected: {ledger.themeMode},
              onSelectionChanged: (s) =>
                  context.read<LedgerProvider>().setThemeMode(s.first),
            ),
          ),
          const SizedBox(height: 8),
          _section(context, 'العملات'),
          for (final c in ledger.currencies)
            ListTile(
              title: Text(c),
              subtitle: c == ledger.defaultCurrency
                  ? const Text('العملة الافتراضية')
                  : null,
              leading: Icon(
                c == ledger.defaultCurrency ? Icons.star : Icons.star_border,
                color: c == ledger.defaultCurrency
                    ? theme.colorScheme.primary
                    : null,
              ),
              onTap: () => context.read<LedgerProvider>().setDefaultCurrency(c),
              trailing: IconButton(
                tooltip: 'حذف العملة',
                icon: const Icon(Icons.delete_outline),
                onPressed: () async {
                  final ok =
                      await context.read<LedgerProvider>().removeCurrency(c);
                  if (!ok && context.mounted) {
                    showSnack(context,
                        'لا يمكن حذف عملة مستخدمة في عمليات، أو العملة الوحيدة');
                  }
                },
              ),
            ),
          ListTile(
            leading: const Icon(Icons.add),
            title: const Text('إضافة عملة'),
            onTap: () => _addCurrency(context),
          ),
          const Divider(),
          _section(context, 'النسخ الاحتياطي'),
          ListTile(
            leading: const Icon(Icons.upload_file_outlined),
            title: const Text('تصدير نسخة احتياطية'),
            subtitle: const Text('ملف يمكنك حفظه أو إرساله لنفسك'),
            onTap: () => _export(context),
          ),
          ListTile(
            leading: const Icon(Icons.download_outlined),
            title: const Text('استيراد نسخة احتياطية'),
            subtitle: const Text('يستبدل كل البيانات الحالية'),
            onTap: () => _import(context),
          ),
          const Divider(),
          _section(context, 'حول التطبيق'),
          const ListTile(
            leading: Icon(Icons.lock_outline),
            title: Text('بياناتك على جهازك فقط'),
            subtitle: Text('لا يوجد حساب ولا إنترنت. النسخ الاحتياطي بيدك.'),
          ),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('دفتر الحسابات'),
            subtitle: Text('الإصدار 1.0.0'),
          ),
        ],
      ),
    );
  }

  Widget _section(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Text(
        title,
        style: Theme.of(context)
            .textTheme
            .titleSmall
            ?.copyWith(color: Theme.of(context).colorScheme.primary),
      ),
    );
  }

  Future<void> _addCurrency(BuildContext context) async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إضافة عملة'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'اسم العملة',
            hintText: 'مثال: ريال سعودي',
          ),
          onSubmitted: (v) => Navigator.pop(ctx, v),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, controller.text),
              child: const Text('إضافة')),
        ],
      ),
    );
    if (name == null || name.trim().isEmpty || !context.mounted) return;
    final ok = await context.read<LedgerProvider>().addCurrency(name);
    if (!ok && context.mounted) {
      showSnack(context, 'هذه العملة موجودة مسبقاً');
    }
  }

  Future<void> _export(BuildContext context) async {
    try {
      final json = context.read<LedgerProvider>().exportJson();
      final dir = await getTemporaryDirectory();
      final stamp = DateFormat('yyyyMMdd_HHmm', 'en').format(DateTime.now());
      final file = File(p.join(dir.path, 'daftar_backup_$stamp.json'));
      await file.writeAsString(json);
      await Share.shareXFiles(
        [XFile(file.path)],
        subject: 'نسخة احتياطية - دفتر الحسابات',
      );
    } catch (_) {
      if (context.mounted) showSnack(context, 'تعذّر إنشاء النسخة الاحتياطية');
    }
  }

  Future<void> _import(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = result?.files.single.path;
    if (path == null || !context.mounted) return;

    final ok = await confirmDialog(
      context,
      title: 'استيراد نسخة احتياطية',
      message: 'سيتم حذف كل البيانات الحالية واستبدالها بمحتوى الملف. هل تريد المتابعة؟',
      action: 'استيراد',
      danger: true,
    );
    if (!ok || !context.mounted) return;

    final ledger = context.read<LedgerProvider>();
    try {
      final text = await File(path).readAsString();
      await ledger.importJson(text);
      if (context.mounted) showSnack(context, 'تم استيراد البيانات بنجاح');
    } on FormatException catch (e) {
      if (context.mounted) showSnack(context, e.message);
    } catch (_) {
      if (context.mounted) showSnack(context, 'تعذّر قراءة الملف');
    }
  }
}
