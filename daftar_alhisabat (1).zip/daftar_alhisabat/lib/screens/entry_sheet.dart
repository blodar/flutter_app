import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/ledger_provider.dart';
import '../utils/format.dart';

/// يفتح نافذة إضافة/تعديل عملية.
/// - [person] : حساب ثابت (عند الفتح من شاشة الشخص)
/// - [entry]  : للتعديل
Future<void> showEntrySheet(
  BuildContext context, {
  Person? person,
  Entry? entry,
  int initialKind = kReceivable,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    showDragHandle: true,
    builder: (_) => EntrySheet(
      person: person,
      entry: entry,
      initialKind: initialKind,
    ),
  );
}

class EntrySheet extends StatefulWidget {
  final Person? person;
  final Entry? entry;
  final int initialKind;

  const EntrySheet({
    super.key,
    this.person,
    this.entry,
    this.initialKind = kReceivable,
  });

  @override
  State<EntrySheet> createState() => _EntrySheetState();
}

class _EntrySheetState extends State<EntrySheet> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _amount = TextEditingController();
  final TextEditingController _note = TextEditingController();

  late int _kind;
  late String _currency;
  late DateTime _date;
  DateTime? _due;
  String? _error;
  bool _saving = false;
  Person? _fixed;

  bool get _editing => widget.entry != null;

  @override
  void initState() {
    super.initState();
    final ledger = context.read<LedgerProvider>();
    final e = widget.entry;
    if (e != null) {
      _fixed = ledger.personById(e.personId);
      _kind = e.kind;
      _currency = e.currency;
      _date = DateTime.fromMillisecondsSinceEpoch(e.date);
      _due = e.due == null ? null : DateTime.fromMillisecondsSinceEpoch(e.due!);
      _amount.text = fmtAmount(e.amount).replaceAll(',', '');
      _note.text = e.note;
    } else {
      _fixed = widget.person;
      _kind = widget.initialKind;
      _currency = ledger.defaultCurrency;
      _date = DateTime.now();
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _pickDate({required bool due}) async {
    final initial = due ? (_due ?? _date) : _date;
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked == null) return;
    setState(() {
      if (due) {
        _due = picked;
      } else {
        _date = picked;
      }
    });
  }

  Future<void> _save() async {
    if (_saving) return;
    final ledger = context.read<LedgerProvider>();

    final amount = parseAmount(_amount.text);
    if (amount == null) {
      setState(() => _error = 'أدخل مبلغاً صحيحاً أكبر من صفر');
      return;
    }
    final name = _name.text.trim();
    if (_fixed == null && name.isEmpty) {
      setState(() => _error = 'أدخل اسم الشخص');
      return;
    }

    setState(() {
      _error = null;
      _saving = true;
    });

    try {
      final personId =
          _fixed != null ? _fixed!.id! : await ledger.personIdForName(name);
      final entry = Entry(
        id: widget.entry?.id,
        personId: personId,
        amount: amount,
        currency: _currency,
        kind: _kind,
        note: _note.text.trim(),
        date: DateTime(_date.year, _date.month, _date.day)
            .millisecondsSinceEpoch,
        due: _due == null
            ? null
            : DateTime(_due!.year, _due!.month, _due!.day)
                .millisecondsSinceEpoch,
      );
      if (_editing) {
        await ledger.updateEntry(entry);
      } else {
        await ledger.addEntry(entry);
      }
      if (!mounted) return;
      Navigator.of(context).pop();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _error = 'تعذّر الحفظ، حاول مرة أخرى';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final ledger = context.watch<LedgerProvider>();
    final theme = Theme.of(context);

    final currencies = [...ledger.currencies];
    if (!currencies.contains(_currency)) currencies.add(_currency);

    final q = _name.text.trim();
    final suggestions = (_fixed != null || q.isEmpty)
        ? <Person>[]
        : ledger.persons
            .where((p) => p.name.contains(q) && p.name.trim() != q)
            .take(6)
            .toList();

    final isReceivable = _kind == kReceivable;
    final kindColor =
        isReceivable ? receivableColor(context) : payableColor(context);

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              _editing ? 'تعديل العملية' : 'عملية جديدة',
              style: theme.textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            if (_fixed != null) ...[
              const SizedBox(height: 4),
              Text(
                _fixed!.name,
                textAlign: TextAlign.center,
                style: theme.textTheme.bodyLarge
                    ?.copyWith(color: theme.colorScheme.primary),
              ),
            ],
            const SizedBox(height: 16),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment<int>(
                  value: kReceivable,
                  label: Text('لي عنده'),
                  icon: Icon(Icons.south_west),
                ),
                ButtonSegment<int>(
                  value: kPayable,
                  label: Text('له عندي'),
                  icon: Icon(Icons.north_east),
                ),
              ],
              selected: {_kind},
              onSelectionChanged: (s) => setState(() => _kind = s.first),
            ),
            const SizedBox(height: 6),
            Text(
              isReceivable
                  ? 'مبلغ يدين به لك هذا الشخص (أقرضته أو بعته آجلاً)'
                  : 'مبلغ تدين به أنت لهذا الشخص (اقترضته أو اشتريت آجلاً)',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodySmall?.copyWith(color: kindColor),
            ),
            const SizedBox(height: 16),
            if (_fixed == null) ...[
              TextField(
                controller: _name,
                textInputAction: TextInputAction.next,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'اسم الشخص',
                  prefixIcon: Icon(Icons.person_outline),
                ),
              ),
              if (suggestions.isNotEmpty) ...[
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    for (final s in suggestions)
                      ActionChip(
                        label: Text(s.name),
                        onPressed: () => setState(() => _name.text = s.name),
                      ),
                  ],
                ),
              ],
              const SizedBox(height: 12),
            ],
            TextField(
              controller: _amount,
              autofocus: _fixed != null && !_editing,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'المبلغ',
                prefixIcon: Icon(Icons.payments_outlined),
              ),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final c in currencies)
                  ChoiceChip(
                    label: Text(c),
                    selected: c == _currency,
                    onSelected: (_) => setState(() => _currency = c),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickDate(due: false),
                    icon: const Icon(Icons.event),
                    label: Text(fmtDateTime(_date)),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _due == null
                      ? OutlinedButton.icon(
                          onPressed: () => _pickDate(due: true),
                          icon: const Icon(Icons.alarm_add_outlined),
                          label: const Text('الاستحقاق'),
                        )
                      : OutlinedButton.icon(
                          onPressed: () => _pickDate(due: true),
                          icon: const Icon(Icons.alarm),
                          label: Text(fmtDateTime(_due!)),
                        ),
                ),
                if (_due != null)
                  IconButton(
                    tooltip: 'إزالة الاستحقاق',
                    onPressed: () => setState(() => _due = null),
                    icon: const Icon(Icons.close),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _note,
              maxLines: 2,
              minLines: 1,
              textInputAction: TextInputAction.done,
              decoration: const InputDecoration(
                labelText: 'ملاحظة (اختياري)',
                prefixIcon: Icon(Icons.notes),
              ),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(
                _error!,
                textAlign: TextAlign.center,
                style: TextStyle(color: theme.colorScheme.error),
              ),
            ],
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: const Icon(Icons.check),
              label: const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }
}
