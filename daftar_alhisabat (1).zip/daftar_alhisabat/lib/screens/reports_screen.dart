import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../providers/ledger_provider.dart';
import '../utils/format.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  String? _currency;

  @override
  Widget build(BuildContext context) {
    final ledger = context.watch<LedgerProvider>();
    final used = ledger.usedCurrencies;

    if (used.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('التقارير')),
        body: const Center(child: Text('لا توجد بيانات لعرض التقارير بعد')),
      );
    }

    final cur = (_currency != null && used.contains(_currency))
        ? _currency!
        : used.first;
    final totals = ledger.totals()[cur] ?? CurrencyTotals();
    final debtors = ledger.topBalances(cur, positive: true);
    final creditors = ledger.topBalances(cur, positive: false);
    final months = ledger.monthlyStats(cur);
    final theme = Theme.of(context);
    final green = receivableColor(context);
    final red = payableColor(context);
    final net = totals.net;

    return Scaffold(
      appBar: AppBar(title: const Text('التقارير')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (used.length > 1)
            Wrap(
              spacing: 8,
              children: [
                for (final c in used)
                  ChoiceChip(
                    label: Text(c),
                    selected: c == cur,
                    onSelected: (_) => setState(() => _currency = c),
                  ),
              ],
            ),
          if (used.length > 1) const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _StatCard(
                    label: 'لي عند الناس',
                    value: totals.receivable,
                    currency: cur,
                    color: green),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _StatCard(
                    label: 'علي للناس',
                    value: totals.payable,
                    currency: cur,
                    color: red),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Text('الصافي', style: theme.textTheme.titleMedium),
                  ),
                  Text(
                    '${net > 0 ? '+' : (net < 0 ? '−' : '')}${fmtAmount(net.abs())} $cur',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: net >= 0 ? green : red,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          _RankCard(
            title: 'أكثر من عليهم لي',
            rows: debtors,
            currency: cur,
            color: green,
            emptyText: 'لا أحد مدين لك بهذه العملة',
          ),
          const SizedBox(height: 12),
          _RankCard(
            title: 'أكثر من لهم عندي',
            rows: creditors,
            currency: cur,
            color: red,
            emptyText: 'ليس عليك ديون بهذه العملة',
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('الحركة خلال آخر 6 أشهر',
                      style: theme.textTheme.titleMedium),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      _legend(green, 'لي عنده'),
                      const SizedBox(width: 16),
                      _legend(red, 'له عندي'),
                    ],
                  ),
                  const SizedBox(height: 12),
                  _MonthlyChart(stats: months, green: green, red: red),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _legend(Color color, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(text, style: const TextStyle(fontSize: 12)),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final double value;
  final String currency;
  final Color color;
  const _StatCard({
    required this.label,
    required this.value,
    required this.currency,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 6),
            Text(
              fmtAmount(value),
              style: TextStyle(
                  fontSize: 20, fontWeight: FontWeight.bold, color: color),
            ),
            Text(currency, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}

class _RankCard extends StatelessWidget {
  final String title;
  final List<MapEntry<Person, double>> rows;
  final String currency;
  final Color color;
  final String emptyText;
  const _RankCard({
    required this.title,
    required this.rows,
    required this.currency,
    required this.color,
    required this.emptyText,
  });

  @override
  Widget build(BuildContext context) {
    final maxV = rows.isEmpty ? 1.0 : rows.first.value;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            if (rows.isEmpty) Text(emptyText),
            for (final r in rows)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(r.key.name,
                              maxLines: 1, overflow: TextOverflow.ellipsis),
                        ),
                        Text(
                          '${fmtAmount(r.value)} $currency',
                          style: TextStyle(
                              color: color, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: (r.value / maxV).clamp(0.0, 1.0).toDouble(),
                        minHeight: 6,
                        color: color,
                        backgroundColor: color.withAlpha(30),
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _MonthlyChart extends StatelessWidget {
  final List<MonthStat> stats;
  final Color green;
  final Color red;
  const _MonthlyChart({
    required this.stats,
    required this.green,
    required this.red,
  });

  static const double _barArea = 120;

  @override
  Widget build(BuildContext context) {
    final maxV = LedgerProvider.maxOf(stats.expand((s) => [s.lent, s.borrowed]));
    if (maxV <= 0) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 12),
        child: Text('لا توجد حركة في هذه الفترة'),
      );
    }
    final fmt = DateFormat('MM/yy', 'en');
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        for (final s in stats)
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  height: _barArea,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _bar(s.lent / maxV, green),
                      const SizedBox(width: 4),
                      _bar(s.borrowed / maxV, red),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                Text(fmt.format(s.month), style: const TextStyle(fontSize: 11)),
              ],
            ),
          ),
      ],
    );
  }

  Widget _bar(double fraction, Color color) {
    final double h = fraction <= 0
        ? 0.0
        : (fraction * _barArea).clamp(3.0, _barArea).toDouble();
    return Container(
      width: 12,
      height: h,
      decoration: BoxDecoration(
        color: color,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
      ),
    );
  }
}
